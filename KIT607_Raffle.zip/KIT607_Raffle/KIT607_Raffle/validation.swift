//
//  validation.swift
//  KIT607_Raffle
//
//  Created by Jin Hou on 22/5/20.
//  Copyright © 2020 Jinzhi Hou. All rights reserved.
//

import Foundation

extension String{
    
    func isValid() -> Bool {
        return true
    }
    
}
